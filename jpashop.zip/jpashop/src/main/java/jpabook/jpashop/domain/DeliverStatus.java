package jpabook.jpashop.domain;

public enum DeliverStatus {
  READY, COMP
}
