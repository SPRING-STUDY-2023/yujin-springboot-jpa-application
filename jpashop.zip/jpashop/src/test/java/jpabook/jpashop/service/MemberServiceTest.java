package jpabook.jpashop.service;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.is;

import jpabook.jpashop.domain.Member;
import jpabook.jpashop.repository.MemberRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;
@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class MemberServiceTest {

  @Autowired MemberService memberService;
  @Autowired MemberRepository memberRepository;

  @Test
//  @DisplayName("")
  public void 회원가입() throws Exception{
      // given
      Member member = new Member();
      member.setName("kim");
      
      // when
    Long saveId = memberService.join(member);
    Member findMember=  memberRepository.findOne(saveId);
      
      // then
    assertThat(findMember.getId(),is(equalTo(member.getId())));
  }
}